import { describe, it, expect } from 'vitest'
import { render, screen } from '@testing-library/react'
import App from '../src/App'

describe('App Component', () => {
  it('renders the application', () => {
    render(<App />)
    expect(screen.getByText(/Welcome to Portal-OS/i)).toBeTruthy()
  })

  it('displays navigation links', () => {
    render(<App />)
    const homeLink = screen.getByRole('link', { name: /Portal-OS/i })
    expect(homeLink).toBeTruthy()
  })

  it('shows Portal-OS title', () => {
    render(<App />)
    const title = screen.getByText(/Portal-OS/)
    expect(title).toBeTruthy()
  })
})
