import { create } from 'zustand'

export const useAuthStore = create((set) => ({
  user: null,
  accessToken: localStorage.getItem('accessToken'),
  refreshToken: localStorage.getItem('refreshToken'),
  isLoading: false,
  error: null,

  login: async (email, password) => {
    set({ isLoading: true, error: null })
    try {
      // TODO: Phase 2 - Implement actual login
      const response = await fetch('http://localhost:8000/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      })
      const data = await response.json()
      if (response.ok) {
        localStorage.setItem('accessToken', data.access_token)
        localStorage.setItem('refreshToken', data.refresh_token)
        set({
          user: data.user,
          accessToken: data.access_token,
          refreshToken: data.refresh_token,
          isLoading: false,
        })
      } else {
        set({ error: data.message || 'Login failed', isLoading: false })
      }
    } catch (error) {
      set({ error: error.message, isLoading: false })
    }
  },

  logout: () => {
    localStorage.removeItem('accessToken')
    localStorage.removeItem('refreshToken')
    set({ user: null, accessToken: null, refreshToken: null })
  },

  setUser: (user) => set({ user }),

  isAuthenticated: () => {
    const state = useAuthStore.getState()
    return !!state.accessToken
  },
}))
