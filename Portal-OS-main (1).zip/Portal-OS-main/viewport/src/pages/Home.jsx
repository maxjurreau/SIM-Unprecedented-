import { useEffect, useState } from 'react'
import { useAuthStore } from '../store/authStore'
import api from '../services/api'

function Home() {
  const { user } = useAuthStore()
  const [apiStatus, setApiStatus] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const checkApiHealth = async () => {
      try {
        const response = await api.get('/health')
        setApiStatus(response.data)
      } catch (error) {
        console.error('Failed to check API health:', error)
        setApiStatus({ error: 'Failed to connect to API' })
      } finally {
        setLoading(false)
      }
    }

    checkApiHealth()
  }, [])

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      <div className="container mx-auto px-4 py-16">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-5xl font-bold text-gray-900 mb-4">
            Welcome to Portal-OS
          </h1>
          <p className="text-xl text-gray-600">
            A company-grade enterprise platform
          </p>
        </div>

        {/* Hero Section */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
          <div className="card">
            <h2 className="text-2xl font-bold text-blue-600 mb-2">🚀 Fast</h2>
            <p className="text-gray-600">
              Built with FastAPI and React for high performance
            </p>
          </div>
          <div className="card">
            <h2 className="text-2xl font-bold text-purple-600 mb-2">🔒 Secure</h2>
            <p className="text-gray-600">
              JWT authentication and OWASP hardened
            </p>
          </div>
          <div className="card">
            <h2 className="text-2xl font-bold text-green-600 mb-2">📊 Observable</h2>
            <p className="text-gray-600">
              Full monitoring with Prometheus and Grafana
            </p>
          </div>
        </div>

        {/* Status Section */}
        <div className="card">
          <h2 className="text-2xl font-bold mb-4">System Status</h2>
          {loading ? (
            <div className="text-center text-gray-500">Checking API health...</div>
          ) : apiStatus?.error ? (
            <div className="text-red-600 font-medium">{apiStatus.error}</div>
          ) : (
            <div className="space-y-2">
              <p className="text-green-600 font-medium">✓ API Status: {apiStatus?.status}</p>
              <p className="text-gray-600">Environment: {apiStatus?.environment}</p>
              <p className="text-gray-600">Version: {apiStatus?.version}</p>
            </div>
          )}
        </div>

        {/* Next Steps */}
        <div className="mt-12 text-center">
          <h2 className="text-2xl font-bold mb-6">Get Started</h2>
          <div className="space-y-3">
            <p className="text-gray-600">Phase 1: Foundation Setup</p>
            <p className="text-gray-600">→ Backend FastAPI skeleton ✓</p>
            <p className="text-gray-600">→ Frontend React skeleton ✓</p>
            <p className="text-gray-600">→ Docker Compose environment</p>
            <p className="text-gray-600 text-sm mt-4">
              Check docs/PHASE_1_PLANNING.md for detailed roadmap
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Home
