"""
Portal-OS FastAPI Application

Main application entry point with health check endpoints and middleware.
"""

import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app.config import settings

# Configure logging
settings.configure_logging()
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifecycle management."""
    # Startup
    logger.info("Portal-OS API starting up...")
    logger.info(f"Environment: {settings.api_env}")
    logger.info(f"Database: {settings.db_host}:{settings.db_port}/{settings.db_name}")
    logger.info(f"Redis: {settings.redis_host}:{settings.redis_port}")
    yield
    # Shutdown
    logger.info("Portal-OS API shutting down...")


# Create FastAPI application
app = FastAPI(
    title=settings.api_title,
    description=settings.api_description,
    version=settings.api_version,
    docs_url="/docs",
    redoc_url="/redoc",
    openapi_url="/openapi.json",
    lifespan=lifespan,
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# Health check endpoints
@app.get("/health", tags=["Health"])
async def health() -> dict:
    """
    Health check endpoint.
    
    Returns:
        dict: Health status
    """
    return {
        "status": "ok",
        "environment": settings.api_env,
        "version": settings.api_version,
    }


@app.get("/ready", tags=["Health"])
async def ready() -> dict:
    """
    Readiness probe endpoint.
    
    Checks if the application is ready to accept requests.
    In Phase 2+, this will verify database and Redis connectivity.
    
    Returns:
        dict: Readiness status
    """
    # TODO: Phase 2 - Add database connectivity check
    # TODO: Phase 2 - Add Redis connectivity check
    return {
        "ready": True,
        "checks": {
            "database": "ok",  # Will check actual connection in Phase 2
            "redis": "ok",     # Will check actual connection in Phase 2
        }
    }


@app.get("/", tags=["Root"])
async def root() -> dict:
    """
    Root endpoint with API information.
    
    Returns:
        dict: API metadata
    """
    return {
        "name": "Portal-OS",
        "version": settings.api_version,
        "description": settings.api_description,
        "docs_url": "/docs",
        "redoc_url": "/redoc",
    }


# Error handlers
@app.exception_handler(Exception)
async def global_exception_handler(request, exc: Exception):
    """Global exception handler."""
    logger.error(f"Unhandled exception: {exc}", exc_info=True)
    return JSONResponse(
        status_code=500,
        content={
            "error": "INTERNAL_SERVER_ERROR",
            "message": "An unexpected error occurred",
            "detail": str(exc) if settings.debug else None,
        },
    )


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "app.main:app",
        host="0.0.0.0",
        port=8000,
        reload=settings.debug,
    )