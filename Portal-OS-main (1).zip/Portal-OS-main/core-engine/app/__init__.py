"""
Portal-OS Backend Application

A company-grade multi-layer platform with core engine, identity physics,
system management, and governance capabilities.
"""

__version__ = "0.1.0"
__author__ = "Portal-OS Team"