# Portal-OS

Multi-layer enterprise platform with core engine, identity physics, system management, and governance.

## Quick Start

### Prerequisites
- Docker and Docker Compose 2.0+
- Python 3.10+ (for local development)
- Node.js 18+ (for frontend development)

### Local Development

```bash
# Clone repository
git clone https://github.com/maxjurreau/Portal-OS.git
cd Portal-OS

# Start services
docker-compose up

# Services will be available at:
# - Frontend: http://localhost:3000
# - Backend API: http://localhost:8000
# - API Docs: http://localhost:8000/docs
# - Database: localhost:5432
# - Redis: localhost:6379
```

### Running Tests

```bash
# Backend tests
docker-compose exec backend pytest

# Frontend tests
docker-compose exec frontend npm test

# Linting
docker-compose exec backend black . && flake8
docker-compose exec frontend npm run lint
```

## Documentation

- [README.md](README.md) - Project overview
- [PHASE_1_PLANNING.md](docs/PHASE_1_PLANNING.md) - Foundation setup
- [PHASE_2_DEVELOPMENT.md](docs/PHASE_2_DEVELOPMENT.md) - Core platform
- [PHASE_3_ADVANCED_FEATURES.md](docs/PHASE_3_ADVANCED_FEATURES.md) - Advanced features
- [PHASE_4_DEPLOYMENT_TESTING.md](docs/PHASE_4_DEPLOYMENT_TESTING.md) - Production deployment

## Development

### Backend Structure

```
core-engine/
├── app/
│   ├── __init__.py
│   ├── main.py          # FastAPI app
│   └── config.py        # Configuration
├── tests/
│   └── test_health.py
├── Dockerfile
├── requirements.txt
└── pytest.ini
```

### Frontend Structure

```
viewport/
├── src/
│   ├── main.jsx         # Entry point
│   ├── App.jsx          # Main app
│   ├── pages/           # Page components
│   ├── components/      # Reusable components
│   ├── services/        # API client
│   ├── store/           # State management
│   └── __tests__/       # Tests
├── Dockerfile
├── package.json
└── vite.config.js
```

## Current Phase

✅ Phase 1: Foundation
- Backend FastAPI skeleton with health checks
- Frontend React skeleton with routing
- Docker Compose environment
- Pre-commit hooks and linting
- Test setup (pytest, Vitest)

## Next Steps

👉 Phase 2: Core Platform (4-5 weeks)
- User authentication (JWT)
- Database schema and ORM
- User and System CRUD
- Session management

See [PHASE_1_PLANNING.md](docs/PHASE_1_PLANNING.md) for complete roadmap.
