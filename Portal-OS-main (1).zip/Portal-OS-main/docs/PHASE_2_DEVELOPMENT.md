# **PHASE 2 — CORE PLATFORM (4–5 weeks)**
**Outcome:** Portal‑OS becomes *alive* — identity, systems, state, CRUD, sessions.

---

## **2.1 Overview**
Phase 2 implements the core business logic of Portal‑OS. The platform gains:
- User authentication & authorization (JWT + refresh tokens)
- Session management with Redis continuity
- Database schema with migrations
- User and System CRUD operations
- Audit logging
- Frontend state management and protected routes
- Full integration between backend and frontend

---

## **2.2 Deliverables**

### Database & Migrations
- [ ] PostgreSQL schema design document
- [ ] Alembic migration: initial schema
- [ ] Alembic migration: users table
- [ ] Alembic migration: systems table
- [ ] Alembic migration: audit_logs table
- [ ] Alembic migration: sessions table
- [ ] Migration test suite

### ORM Models & Database Layer
- [ ] `User` model (id, email, password_hash, created_at, updated_at)
- [ ] `System` model (id, name, description, owner_id, created_at, updated_at)
- [ ] `AuditLog` model (id, user_id, action, resource_type, resource_id, timestamp)
- [ ] `Session` model (id, user_id, token, expires_at, created_at)
- [ ] Database session management utilities
- [ ] Connection pooling configuration

### Authentication Endpoints
- [ ] `POST /auth/register` — User registration
- [ ] `POST /auth/login` — User login (returns access + refresh tokens)
- [ ] `POST /auth/refresh` — Refresh access token
- [ ] `GET /auth/verify` — Verify current token
- [ ] `POST /auth/logout` — Logout and invalidate session
- [ ] Password hashing (bcrypt)
- [ ] JWT token generation & validation
- [ ] Token expiration middleware

### User Management Endpoints
- [ ] `GET /users` — List all users (with pagination, filtering)
- [ ] `GET /users/{id}` — Get user by ID
- [ ] `POST /users` — Create new user (admin only)
- [ ] `PUT /users/{id}` — Update user profile
- [ ] `DELETE /users/{id}` — Delete user (soft delete)
- [ ] User validation & error handling
- [ ] Authorization middleware

### System Management Endpoints
- [ ] `GET /systems` — List all systems (user-scoped)
- [ ] `GET /systems/{id}` — Get system details
- [ ] `POST /systems` — Create new system
- [ ] `PUT /systems/{id}` — Update system
- [ ] `DELETE /systems/{id}` — Delete system
- [ ] System ownership & permissions validation
- [ ] Query optimization (eager loading, indexes)

### Audit Logging
- [ ] Audit log middleware (logs all POST, PUT, DELETE requests)
- [ ] `GET /audit-logs` — Retrieve audit logs
- [ ] Audit log filtering by user, action, timestamp
- [ ] Immutable audit log storage

### Frontend State Management
- [ ] Zustand or Redux store setup
- [ ] Auth store (login, logout, token refresh)
- [ ] User store (current user profile)
- [ ] System store (list, create, update, delete)
- [ ] State persistence (localStorage for tokens)
- [ ] Error handling middleware

### Frontend Pages & Components
- [ ] `LoginPage` component
- [ ] `RegisterPage` component
- [ ] `Dashboard` page (main hub)
- [ ] `SystemsPage` (list & manage systems)
- [ ] `UserProfilePage` (edit user info)
- [ ] `NotFoundPage` (404 handling)
- [ ] Protected route wrapper
- [ ] Navigation header with user menu

### Frontend API Client
- [ ] Axios interceptors (attach auth tokens)
- [ ] Auto token refresh on 401
- [ ] Global error handling
- [ ] API base URL configuration

### Testing
- [ ] Unit tests for ORM models
- [ ] Unit tests for auth logic (password hashing, JWT)
- [ ] Integration tests for auth endpoints
- [ ] Integration tests for CRUD endpoints
- [ ] Frontend component tests (login, register, dashboard)
- [ ] Frontend integration tests (full auth flow)
- [ ] Test coverage: >85%

### Documentation
- [ ] Database schema diagram (ERD)
- [ ] API documentation (OpenAPI/Swagger)
- [ ] Auth flow diagram
- [ ] State management documentation
- [ ] Error code reference
- [ ] Environment variables guide

---

## **2.3 Database Schema**

### Users Table
```sql
CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email VARCHAR(255) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  first_name VARCHAR(255),
  last_name VARCHAR(255),
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  deleted_at TIMESTAMP
);
```

### Systems Table
```sql
CREATE TABLE systems (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name VARCHAR(255) NOT NULL,
  description TEXT,
  owner_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  status VARCHAR(50) DEFAULT 'active',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  deleted_at TIMESTAMP
);
```

### AuditLogs Table
```sql
CREATE TABLE audit_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE SET NULL,
  action VARCHAR(50) NOT NULL,
  resource_type VARCHAR(100) NOT NULL,
  resource_id UUID,
  changes JSONB,
  ip_address VARCHAR(45),
  timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### Sessions Table
```sql
CREATE TABLE sessions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  refresh_token VARCHAR(500) NOT NULL UNIQUE,
  expires_at TIMESTAMP NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

---

## **2.4 API Endpoints Reference**

### Authentication
| Method | Endpoint | Description | Auth Required |
|--------|----------|-------------|---------------|
| POST | `/auth/register` | Register new user | No |
| POST | `/auth/login` | Login user | No |
| POST | `/auth/refresh` | Refresh access token | Yes (Refresh Token) |
| GET | `/auth/verify` | Verify current token | Yes |
| POST | `/auth/logout` | Logout user | Yes |

### Users
| Method | Endpoint | Description | Auth Required |
|--------|----------|-------------|---------------|
| GET | `/users` | List all users | Yes |
| GET | `/users/{id}` | Get user by ID | Yes |
| POST | `/users` | Create new user | Yes (Admin) |
| PUT | `/users/{id}` | Update user | Yes (Owner or Admin) |
| DELETE | `/users/{id}` | Delete user | Yes (Admin) |

### Systems
| Method | Endpoint | Description | Auth Required |
|--------|----------|-------------|---------------|
| GET | `/systems` | List user's systems | Yes |
| GET | `/systems/{id}` | Get system details | Yes |
| POST | `/systems` | Create new system | Yes |
| PUT | `/systems/{id}` | Update system | Yes (Owner) |
| DELETE | `/systems/{id}` | Delete system | Yes (Owner) |

### Audit
| Method | Endpoint | Description | Auth Required |
|--------|----------|-------------|---------------|
| GET | `/audit-logs` | List audit logs | Yes (Admin) |

---

## **2.5 Authentication Flow**

```
User Registration:
1. POST /auth/register { email, password, name }
2. Backend: Hash password (bcrypt), create user record
3. Backend: Generate JWT access token (15 min expiry)
4. Backend: Generate refresh token, store in DB
5. Return: { accessToken, refreshToken, user }

User Login:
1. POST /auth/login { email, password }
2. Backend: Verify email exists, check password hash
3. Backend: Generate JWT access token (15 min expiry)
4. Backend: Generate refresh token, store in DB
5. Redis: Cache user session (expires_at = access_token expiry)
6. Return: { accessToken, refreshToken, user }

Token Refresh:
1. POST /auth/refresh { refreshToken }
2. Backend: Verify refresh token exists in DB, not expired
3. Backend: Generate new access token
4. Redis: Update session cache
5. Return: { accessToken, refreshToken }

Protected Requests:
1. Client sends: GET /systems (with Authorization: Bearer <accessToken>)
2. Middleware: Extract and validate JWT
3. If invalid/expired: Return 401
4. Frontend interceptor: If 401, call POST /auth/refresh
5. Retry original request with new token
6. If refresh fails: Redirect to login
```

---

## **2.6 State Management (Zustand Example)**

### Auth Store
```javascript
// src/store/authStore.js
import create from 'zustand';

export const useAuthStore = create((set) => ({
  user: null,
  accessToken: localStorage.getItem('accessToken'),
  refreshToken: localStorage.getItem('refreshToken'),
  
  login: async (email, password) => {
    // API call, set tokens & user
  },
  
  logout: () => {
    // Clear tokens & user
  },
  
  refreshToken: async () => {
    // Refresh access token
  },
  
  isAuthenticated: () => !!get().accessToken,
}));
```

### System Store
```javascript
// src/store/systemStore.js
export const useSystemStore = create((set) => ({
  systems: [],
  loading: false,
  
  fetchSystems: async () => {
    // GET /systems
  },
  
  createSystem: async (data) => {
    // POST /systems
  },
  
  updateSystem: async (id, data) => {
    // PUT /systems/{id}
  },
  
  deleteSystem: async (id) => {
    // DELETE /systems/{id}
  },
}));
```

---

## **2.7 Error Handling**

### Backend Error Responses
```json
{
  "error": "INVALID_CREDENTIALS",
  "message": "Email or password is incorrect",
  "status": 401,
  "timestamp": "2024-09-01T10:30:00Z"
}
```

### Common Error Codes
| Code | HTTP Status | Description |
|------|------------|-------------|
| INVALID_CREDENTIALS | 401 | Email/password mismatch |
| TOKEN_EXPIRED | 401 | JWT token expired |
| UNAUTHORIZED | 403 | User lacks permission |
| RESOURCE_NOT_FOUND | 404 | User/system not found |
| EMAIL_ALREADY_EXISTS | 409 | Duplicate email |
| VALIDATION_ERROR | 422 | Invalid input data |

---

## **2.8 Success Criteria**

- [ ] All auth endpoints working (register, login, refresh, logout, verify)
- [ ] User CRUD endpoints fully operational
- [ ] System CRUD endpoints fully operational
- [ ] Token refresh works seamlessly (auto-refresh on 401)
- [ ] Audit logs captured for all mutations
- [ ] Database migrations run without errors
- [ ] Frontend login/register pages functional
- [ ] Protected routes block unauthenticated users
- [ ] Dashboard displays logged-in user info
- [ ] Systems list and CRUD work end-to-end
- [ ] Test coverage >85% (backend + frontend)
- [ ] API documentation complete (Swagger/OpenAPI)
- [ ] No SQL injection or XSS vulnerabilities
- [ ] Password hashing uses bcrypt (min 10 rounds)
- [ ] All tests passing in CI/CD

---

## **2.9 Timeline (4–5 weeks)**

| Milestone | Duration | Owner |
|-----------|----------|-------|
| Database schema & migrations | 3–4 days | Backend Lead |
| ORM models & database layer | 2–3 days | Backend Lead |
| Auth endpoints | 4–5 days | Backend Lead |
| CRUD endpoints (users, systems) | 3–4 days | Backend Lead |
| Audit logging | 2 days | Backend Lead |
| Frontend state management | 3 days | Frontend Lead |
| Frontend pages (login, register, dashboard) | 4–5 days | Frontend Lead |
| Frontend API client & interceptors | 2 days | Frontend Lead |
| Integration testing | 4–5 days | QA Lead |
| Documentation & refinement | 3–4 days | Tech Lead |
| **Phase 2 Complete** | **4–5 weeks** | Team |

---

## **2.10 Dependencies**

- Phase 1 (Foundation) must be complete
- PostgreSQL and Redis must be running (via docker-compose)
- Backend and frontend skeletons operational

---

## **2.11 Known Risks & Mitigations**

| Risk | Probability | Impact | Mitigation |
|------|-------------|--------|------------|
| Token refresh race condition | Medium | High | Use atomic DB operations, mutex on refresh |
| SQL injection via search filters | Low | Critical | Use parameterized queries (SQLAlchemy) |
| Password stored in plain text | Low | Critical | Enforce bcrypt hashing in code review |
| Refresh token leaked | Low | High | Rotate tokens on each refresh, short expiry |
| Frontend state loss on page reload | Medium | Medium | Persist tokens to localStorage |
| Slow API calls | Medium | Medium | Add pagination, indexes on frequently queried columns |

---

**END OF PHASE 2 PLANNING**

Next: [PHASE 3 ADVANCED FEATURES](./PHASE_3_ADVANCED_FEATURES.md)
