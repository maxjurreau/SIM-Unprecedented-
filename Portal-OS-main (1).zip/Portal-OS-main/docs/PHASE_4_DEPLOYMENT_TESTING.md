# **PHASE 4 — DEPLOYMENT & OPERATIONS (3–4 weeks)**
**Outcome:** Portal‑OS becomes *production‑ready* — HA, DR, monitoring, CI/CD.

---

## **4.1 Overview**
Phase 4 hardens Portal‑OS for production deployment with:
- Comprehensive testing suite (unit, integration, E2E, load, security)
- Kubernetes deployment manifests for all services
- High Availability (HA) configuration with redundancy
- Disaster Recovery (DR) procedures with RPO/RTO targets
- Full observability (Prometheus, Grafana, ELK Stack)
- Operational runbooks for incident response
- Production deployment and cutover strategy

---

## **4.2 Deliverables**

### Testing Suite
- [ ] Unit tests for all backend modules (>90% coverage)
- [ ] Unit tests for all frontend components (>85% coverage)
- [ ] Integration tests for auth flow, CRUD operations, audit logging
- [ ] End-to-End (E2E) tests using Cypress or Selenium
- [ ] Load testing (1000+ concurrent users) using Apache JMeter or k6
- [ ] Performance benchmarking suite
- [ ] Security testing (OWASP, penetration testing)
- [ ] Automated test execution in CI/CD pipeline
- [ ] Test result reporting and metrics

### Kubernetes Deployment
- [ ] Kubernetes cluster setup (AWS EKS, GCP GKE, or on-premise)
- [ ] Dockerfile optimization (multi-stage builds, minimal images)
- [ ] Deployment manifests for API service
- [ ] Deployment manifests for frontend service
- [ ] StatefulSet for PostgreSQL database
- [ ] Deployment for Redis cache
- [ ] Ingress configuration (nginx or istio)
- [ ] Service discovery configuration
- [ ] Resource requests and limits
- [ ] Horizontal Pod Autoscaling (HPA)
- [ ] Vertical Pod Autoscaling (VPA)

### High Availability (HA)
- [ ] Multi-zone Kubernetes cluster
- [ ] Pod Disruption Budgets (PDB)
- [ ] Database replication (PostgreSQL streaming replication)
- [ ] Redis Sentinel for automatic failover
- [ ] Connection pooling (PgBouncer)
- [ ] Load balancing (L4 + L7)
- [ ] Health checks (readiness + liveness probes)
- [ ] Graceful shutdown handling
- [ ] Zero-downtime deployments (rolling updates)

### Disaster Recovery (DR)
- [ ] Backup strategy (automated daily backups)
- [ ] Backup retention policy (30-day rolling window)
- [ ] Backup encryption (at-rest and in-transit)
- [ ] Backup restoration testing (monthly)
- [ ] Point-in-Time Recovery (PITR) capability
- [ ] Geographic redundancy (multi-region setup)
- [ ] Failover automation
- [ ] Failback procedures
- [ ] RPO target: 15 minutes
- [ ] RTO target: 1 hour

### Monitoring & Observability
- [ ] Prometheus setup and configuration
- [ ] Custom metrics export from application
- [ ] Grafana dashboards for key metrics
- [ ] Alert rules (CPU, memory, disk, response time, error rate)
- [ ] Alert routing (PagerDuty, Slack)
- [ ] ELK Stack setup (Elasticsearch, Logstash, Kibana)
- [ ] Centralized logging from all services
- [ ] Log retention policy
- [ ] Distributed tracing (Jaeger or Zipkin)
- [ ] APM (Application Performance Monitoring)

### Operational Runbooks
- [ ] Incident response playbook
- [ ] On-call procedures and escalation paths
- [ ] Database failover runbook
- [ ] Service rollback strategy
- [ ] Performance degradation investigation guide
- [ ] Data corruption recovery procedure
- [ ] Network partition handling
- [ ] Out-of-memory (OOM) kill response
- [ ] Disk space exhaustion recovery
- [ ] Dependency failure handling

### CI/CD Pipeline
- [ ] GitHub Actions workflow for automated testing
- [ ] Docker image building and pushing to registry
- [ ] Kubernetes manifest validation
- [ ] Helm chart setup (optional)
- [ ] Staging environment deployment
- [ ] Approval gate for production deployment
- [ ] Automated smoke tests post-deployment
- [ ] Rollback automation on test failure
- [ ] Deployment notifications

### Security & Compliance
- [ ] Secrets management (HashiCorp Vault or AWS Secrets Manager)
- [ ] Network policies (deny-all default, allow specific traffic)
- [ ] Pod security policies
- [ ] Container image scanning for vulnerabilities
- [ ] Compliance audit (SOC 2, GDPR, HIPAA if applicable)
- [ ] SSL/TLS certificate management
- [ ] RBAC for Kubernetes cluster access
- [ ] API rate limiting in production
- [ ] DDoS protection strategy

### Documentation
- [ ] Deployment guide (step-by-step)
- [ ] Operations manual
- [ ] Runbooks for common scenarios
- [ ] Troubleshooting guide
- [ ] Monitoring dashboard guide
- [ ] Backup and recovery procedures
- [ ] Scaling procedures (horizontal and vertical)
- [ ] Capacity planning document
- [ ] Go-live checklist

---

## **4.3 Kubernetes Architecture**

```yaml
# Namespace
---
apiVersion: v1
kind: Namespace
metadata:
  name: portal-os

# ConfigMap
---
apiVersion: v1
kind: ConfigMap
metadata:
  name: portal-os-config
  namespace: portal-os
data:
  API_ENV: "production"
  LOG_LEVEL: "info"

# Secret
---
apiVersion: v1
kind: Secret
metadata:
  name: portal-os-secrets
  namespace: portal-os
type: Opaque
data:
  DB_PASSWORD: <base64-encoded>
  JWT_SECRET: <base64-encoded>
  SMTP_PASSWORD: <base64-encoded>

# API Deployment
---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: portal-os-api
  namespace: portal-os
spec:
  replicas: 3
  strategy:
    type: RollingUpdate
    rollingUpdate:
      maxSurge: 1
      maxUnavailable: 0
  selector:
    matchLabels:
      app: portal-os-api
  template:
    metadata:
      labels:
        app: portal-os-api
    spec:
      containers:
      - name: api
        image: myregistry.azurecr.io/portal-os-api:latest
        ports:
        - containerPort: 8000
        env:
        - name: DB_HOST
          value: postgres-service
        - name: REDIS_HOST
          value: redis-service
        - name: JWT_SECRET
          valueFrom:
            secretKeyRef:
              name: portal-os-secrets
              key: JWT_SECRET
        resources:
          requests:
            cpu: 250m
            memory: 512Mi
          limits:
            cpu: 1000m
            memory: 2Gi
        livenessProbe:
          httpGet:
            path: /health
            port: 8000
          initialDelaySeconds: 30
          periodSeconds: 10
          timeoutSeconds: 5
        readinessProbe:
          httpGet:
            path: /ready
            port: 8000
          initialDelaySeconds: 10
          periodSeconds: 5

# Frontend Deployment
---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: portal-os-frontend
  namespace: portal-os
spec:
  replicas: 2
  selector:
    matchLabels:
      app: portal-os-frontend
  template:
    metadata:
      labels:
        app: portal-os-frontend
    spec:
      containers:
      - name: frontend
        image: myregistry.azurecr.io/portal-os-frontend:latest
        ports:
        - containerPort: 3000
        resources:
          requests:
            cpu: 100m
            memory: 256Mi
          limits:
            cpu: 500m
            memory: 1Gi

# API Service
---
apiVersion: v1
kind: Service
metadata:
  name: portal-os-api-service
  namespace: portal-os
spec:
  type: ClusterIP
  selector:
    app: portal-os-api
  ports:
  - port: 8000
    targetPort: 8000

# Frontend Service
---
apiVersion: v1
kind: Service
metadata:
  name: portal-os-frontend-service
  namespace: portal-os
spec:
  type: ClusterIP
  selector:
    app: portal-os-frontend
  ports:
  - port: 3000
    targetPort: 3000

# Ingress
---
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: portal-os-ingress
  namespace: portal-os
  annotations:
    cert-manager.io/cluster-issuer: "letsencrypt-prod"
    nginx.ingress.kubernetes.io/rate-limit: "100"
spec:
  ingressClassName: nginx
  tls:
  - hosts:
    - portal.example.com
    secretName: portal-tls
  rules:
  - host: portal.example.com
    http:
      paths:
      - path: /api
        pathType: Prefix
        backend:
          service:
            name: portal-os-api-service
            port:
              number: 8000
      - path: /
        pathType: Prefix
        backend:
          service:
            name: portal-os-frontend-service
            port:
              number: 3000

# HPA for API
---
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: portal-os-api-hpa
  namespace: portal-os
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: portal-os-api
  minReplicas: 3
  maxReplicas: 10
  metrics:
  - type: Resource
    resource:
      name: cpu
      target:
        type: Utilization
        averageUtilization: 70
  - type: Resource
    resource:
      name: memory
      target:
        type: Utilization
        averageUtilization: 80
```

---

## **4.4 Monitoring Setup**

### Prometheus Scrape Config
```yaml
# prometheus.yml
global:
  scrape_interval: 15s
  evaluation_interval: 15s

scrape_configs:
- job_name: 'portal-os-api'
  static_configs:
  - targets: ['localhost:8000']
  metrics_path: '/metrics'

- job_name: 'kubernetes-pods'
  kubernetes_sd_configs:
  - role: pod
  relabel_configs:
  - source_labels: [__meta_kubernetes_pod_annotation_prometheus_io_scrape]
    action: keep
    regex: true
```

### Alert Rules
```yaml
# alert-rules.yml
groups:
- name: portal-os-alerts
  rules:
  - alert: HighCPUUsage
    expr: container_cpu_usage_seconds_total > 0.8
    for: 5m
    annotations:
      summary: "High CPU usage detected"

  - alert: HighMemoryUsage
    expr: container_memory_usage_bytes / container_spec_memory_limit_bytes > 0.9
    for: 5m
    annotations:
      summary: "High memory usage detected"

  - alert: HighErrorRate
    expr: rate(http_requests_total{status=~"5.."}[5m]) > 0.05
    for: 5m
    annotations:
      summary: "High error rate detected"

  - alert: DatabaseDown
    expr: up{job="postgres"} == 0
    for: 1m
    annotations:
      summary: "Database is down"
```

---

## **4.5 Disaster Recovery Plan**

### Backup Strategy
- **Frequency:** Automated backups every 6 hours
- **Retention:** 30-day rolling window (5 backups per day)
- **Location:** Off-site geographic redundancy
- **Encryption:** AES-256 at-rest, TLS in-transit
- **Verification:** Weekly backup restoration test

### Recovery Procedures

**RTO: 1 hour, RPO: 15 minutes**

#### Database Failover
1. Monitor primary DB health continuously
2. If primary fails, Redis Sentinel triggers failover
3. Standby database promotes to primary (< 30 seconds)
4. Application connection string updates automatically
5. Verify data consistency
6. Alert on-call team

#### Point-in-Time Recovery (PITR)
1. Identify recovery target time
2. Restore from backup to recovery environment
3. Apply transaction logs up to target time
4. Verify recovery
5. Promote recovery DB to production (if needed)
6. Replication from backup to restore standby

#### Multi-Region Failover
1. Primary region fails (detect within 5 minutes)
2. Health check confirms unavailability
3. DNS failover to secondary region (< 2 minutes)
4. Secondary region's standby database promotes
5. Verify data consistency and application health
6. Gradual traffic shift to secondary region

---

## **4.6 Operational Runbooks**

### Runbook: High Error Rate Response
```
**Alert:** HighErrorRate
**Threshold:** >5% of requests return 5xx status
**Response Time:** 5 minutes

Steps:
1. Acknowledge alert in PagerDuty
2. Check API logs: kubectl logs -l app=portal-os-api
3. Check Grafana dashboard for error details
4. If DB connection pool exhausted:
   - Increase pool size: UPDATE CONFIG SET max_connections = X
5. If OOM (Out of Memory):
   - Scale down other services
   - Increase pod memory limit
6. If resource contention:
   - Trigger horizontal pod autoscaling
7. If code-related:
   - Check recent deployments
   - Prepare rollback: kubectl rollout undo deployment/portal-os-api
8. Document incident in wiki
```

### Runbook: Database Failover
```
**Alert:** DatabaseDown
**Threshold:** Primary DB unreachable for 1 minute
**RTO:** 1 hour

Steps:
1. Page on-call DBA
2. Verify primary DB is unreachable (try SSH, check status)
3. If primary is truly down:
   - Trigger failover: redis-sentinel failover portal-os-master
4. Monitor failover status in Sentinel dashboard
5. Update application config to point to new primary
6. Run smoke tests: curl https://portal.example.com/health
7. Verify data integrity:
   - SELECT COUNT(*) from users;
   - SELECT COUNT(*) from systems;
8. Document incident, begin RCA
9. Plan recovery of failed primary DB
```

### Runbook: Disk Space Exhaustion
```
**Alert:** DiskSpaceLow (>90% usage)
**Response Time:** 30 minutes

Steps:
1. Identify which disk is full: df -h
2. Find largest consumers: du -sh /var/lib/postgresql/*
3. If old logs:
   - Archive logs to cold storage: tar -czf logs-archive-$(date +%Y%m%d).tar.gz /var/log/
   - Delete local logs: rm -rf /var/log/postgresql/*.log
4. If database bloat:
   - VACUUM FULL; (during maintenance window)
   - REINDEX; (rebuild indexes)
5. If file uploads:
   - Delete expired files: DELETE FROM files WHERE created_at < now() - INTERVAL '90 days';
6. Set up disk usage alerting threshold
7. Plan storage expansion
```

---

## **4.7 CI/CD Pipeline**

### GitHub Actions Workflow
```yaml
name: Deploy to Production

on:
  push:
    branches: [main]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v2
    - name: Run backend tests
      run: cd core-engine && pytest --cov
    - name: Run frontend tests
      run: cd viewport && npm test -- --coverage
    - name: SonarQube scan
      run: sonar-scanner

  build:
    needs: test
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v2
    - name: Build Docker images
      run: |
        docker build -t myregistry/portal-os-api:${{ github.sha }} core-engine/
        docker build -t myregistry/portal-os-frontend:${{ github.sha }} viewport/
    - name: Scan images for vulnerabilities
      run: trivy image --severity HIGH myregistry/portal-os-api:${{ github.sha }}
    - name: Push to registry
      run: docker push myregistry/portal-os-api:${{ github.sha }}

  deploy-staging:
    needs: build
    runs-on: ubuntu-latest
    steps:
    - name: Deploy to staging
      run: |
        kubectl set image deployment/portal-os-api \
          portal-os-api=myregistry/portal-os-api:${{ github.sha }} \
          -n staging
    - name: Run E2E tests
      run: npm run e2e:staging

  deploy-production:
    needs: deploy-staging
    runs-on: ubuntu-latest
    environment: production
    steps:
    - name: Manual approval required
      run: echo "Waiting for manual approval"
    - name: Deploy to production
      run: |
        kubectl set image deployment/portal-os-api \
          portal-os-api=myregistry/portal-os-api:${{ github.sha }} \
          -n portal-os
    - name: Smoke tests
      run: curl -f https://portal.example.com/health
    - name: Notify Slack
      run: |
        curl -X POST ${{ secrets.SLACK_WEBHOOK }} \
          -d '{"text":"Portal-OS deployed to production: ${{ github.sha }}"}'
```

---

## **4.8 Success Criteria**

- [ ] All tests passing (unit, integration, E2E, load, security)
- [ ] Kubernetes cluster operational with 3+ nodes
- [ ] API and frontend deployed to production
- [ ] Database and Redis running with replication
- [ ] Health checks passing consistently
- [ ] Prometheus scraping metrics from all services
- [ ] Grafana dashboards showing real-time metrics
- [ ] ELK Stack collecting and indexing logs
- [ ] Alerts routing to PagerDuty/Slack correctly
- [ ] Load testing passing at 1000+ concurrent users
- [ ] Zero-downtime deployment validated
- [ ] Backup and restore tested successfully
- [ ] DR failover tested and working
- [ ] Runbooks reviewed and tested
- [ ] On-call rotation configured
- [ ] Monitoring alerts tuned (no false positives)
- [ ] Documentation complete and reviewed
- [ ] Security scan shows no critical vulnerabilities
- [ ] Compliance audit passed (if applicable)
- [ ] Go-live approval obtained from leadership

---

## **4.9 Timeline (3–4 weeks)**

| Milestone | Duration | Owner |
|-----------|----------|-------|
| Testing suite completion | 5–6 days | QA Lead |
| Kubernetes setup + manifests | 4–5 days | DevOps Lead |
| Database HA configuration | 3–4 days | DevOps Lead |
| Monitoring setup (Prometheus + Grafana) | 3–4 days | DevOps Lead |
| Logging setup (ELK Stack) | 2–3 days | DevOps Lead |
| DR procedures & testing | 4–5 days | DevOps Lead |
| Runbooks creation | 3–4 days | Tech Lead |
| CI/CD pipeline setup | 3–4 days | DevOps Lead |
| Security hardening & audit | 3–4 days | Security Lead |
| Staging deployment | 2–3 days | DevOps Lead |
| Production deployment | 1 day | DevOps Lead |
| Post-launch verification | 2–3 days | QA Lead |
| **Phase 4 Complete** | **3–4 weeks** | Team |

---

## **4.10 Production Checklist**

### Pre-Launch (Day Before)
- [ ] Backup current production data
- [ ] Verify staging deployment successful
- [ ] Test all critical user workflows
- [ ] Notify users of maintenance window
- [ ] Brief on-call team on incident response
- [ ] Verify rollback procedure works
- [ ] Set up war room communication

### Go-Live (Day Of)
- [ ] Start monitoring dashboards
- [ ] Deploy API canary (10% traffic)
- [ ] Monitor error rates and latency
- [ ] Gradually increase traffic (25% → 50% → 100%)
- [ ] Run smoke tests every 5 minutes
- [ ] Monitor database performance
- [ ] Verify email notifications working
- [ ] Confirm users can log in and access systems

### Post-Launch (24-48 hours)
- [ ] Monitor system stability continuously
- [ ] Analyze logs for errors or warnings
- [ ] Collect user feedback
- [ ] Document any issues encountered
- [ ] Verify backup procedures working
- [ ] Check monitoring alerting accuracy
- [ ] Gradual return to normal operating procedures

---

## **4.11 Known Risks & Mitigations**

| Risk | Probability | Impact | Mitigation |
|------|-------------|--------|------------|
| Database replication lag | Medium | High | Monitor replication lag, alert if >5s |
| Pod eviction during node drain | Medium | High | Set Pod Disruption Budget minAvailable=1 |
| Certificate renewal failure | Low | High | 30-day advance alerts, automation via cert-manager |
| Kubernetes API rate limit | Low | Medium | Cluster autoscaler configured properly |
| Helm chart merge conflicts | Low | Medium | Use GitOps, test helm templates in CI |
| Secrets exposure in logs | Low | Critical | Log all secrets access, use external secrets manager |

---

**END OF PHASE 4 PLANNING**

---

# **PORTAL‑OS BUILD COMPLETE**

All four phases complete. Portal‑OS is now:
- ✅ **Foundation** (Phase 1)
- ✅ **Core Platform** (Phase 2)
- ✅ **Company-Grade** (Phase 3)
- ✅ **Production-Ready** (Phase 4)

**Total Build Time:** 13–18 weeks
**Team Size:** 8–12 engineers
**Go-Live:** Ready for production deployment

---

Next Steps:
1. Schedule Phase 1 kickoff meeting
2. Assign team leads for each workstream
3. Set up project tracking board
4. Begin infrastructure provisioning
5. Initiate development sprints

**Let's build Portal‑OS.** 🚀
