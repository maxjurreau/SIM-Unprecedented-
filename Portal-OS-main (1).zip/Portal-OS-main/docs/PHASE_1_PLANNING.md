# **PHASE 1 — FOUNDATION (2–3 weeks)**
**Outcome:** A fully structured, bootable, standards‑driven project.

---

## **1.1 Overview**
Phase 1 establishes the skeleton infrastructure for Portal‑OS. By the end of this phase, the project will have:
- A runnable FastAPI backend with health endpoints
- A runnable React frontend with routing
- Docker Compose environment for local development
- Pre-commit hooks and linting standards
- Repository structure aligned with company standards
- Complete architecture and coding guidelines documentation

---

## **1.2 Deliverables**

### Backend
- [ ] FastAPI app initialized with Uvicorn
- [ ] Health check endpoint (`GET /health`)
- [ ] Base error handling middleware
- [ ] Logging configuration (stdout + file)
- [ ] Requirements.txt with base dependencies
- [ ] .env.example file

### Frontend
- [ ] React 18 app initialized with Vite/CRA
- [ ] React Router v6 setup
- [ ] TailwindCSS configured
- [ ] Axios client with base configuration
- [ ] Basic page structure (Home, NotFound)
- [ ] Package.json with dev dependencies

### Development Infrastructure
- [ ] Docker & docker-compose files (backend, frontend, PostgreSQL, Redis)
- [ ] .gitignore (Python, Node)
- [ ] Pre-commit hooks (black, flake8, prettier)
- [ ] GitHub Actions CI/CD skeleton (.github/workflows)

### Documentation
- [ ] README.md (project overview, local setup)
- [ ] ARCHITECTURE.md (system design overview)
- [ ] CODING_STANDARDS.md (Python & JavaScript conventions)
- [ ] DEV_SETUP.md (step-by-step local environment guide)
- [ ] CONTRIBUTING.md (PR guidelines, commit message format)

### Testing
- [ ] pytest configuration (backend)
- [ ] Jest/Vitest configuration (frontend)
- [ ] Initial health check tests
- [ ] GitHub Actions test workflow

---

## **1.3 Technical Specifications**

### Backend Stack
```
FastAPI==0.104.0
SQLAlchemy==2.0.0
Alembic==1.12.0
psycopg2-binary==2.9.9
pydantic==2.0.0
python-dotenv==1.0.0
redis==5.0.0
pytest==7.4.0
black==23.9.0
flake8==6.0.0
```

### Frontend Stack
```
react@18.x
react-router-dom@6.x
axios@1.x
tailwindcss@3.x
vite@5.x or create-react-app@5.x
jest@29.x or vitest@0.x
prettier@3.x
```

### Infrastructure
```
Docker 20.10+
docker-compose 2.0+
PostgreSQL 15
Redis 7.0
```

---

## **1.4 Repository Structure (to be created)**

```
Portal-OS/
├── core-engine/
│   ├── app/
│   │   ├── __init__.py
│   │   ├── main.py (FastAPI app initialization)
│   │   ├── config.py (settings management)
│   │   └── routes.py (health endpoint)
│   ├── tests/
│   │   ├── __init__.py
│   │   └── test_health.py
│   ├── Dockerfile
│   ├── requirements.txt
│   ├── .env.example
│   └── pytest.ini
│
├── viewport/
│   ├── src/
│   │   ├── main.jsx
│   │   ├── App.jsx
│   │   ├── pages/
│   │   │   ├── Home.jsx
│   │   │   └── NotFound.jsx
│   │   ├── components/
│   │   │   └── Layout.jsx
│   │   ├── services/
│   │   │   └── api.js (Axios client)
│   │   ├── App.css
│   │   └── index.css
│   ├── Dockerfile
│   ├── package.json
│   ├── vite.config.js or craco.config.js
│   ├── tailwind.config.js
│   ├── .env.example
│   └── vitest.config.js or jest.config.js
│
├── infra/
│   ├── docker/
│   │   └── docker-compose.yml
│   └── .env.example
│
├── docs/
│   ├── MASTER.md
│   ├── ARCHITECTURE.md
│   ├── CODING_STANDARDS.md
│   ├── DEV_SETUP.md
│   ├── CONTRIBUTING.md
│   ├── README.md (project overview)
│   ├── PHASE_1_PLANNING.md (this file)
│   ├── PHASE_2_DEVELOPMENT.md
│   ├── PHASE_3_ADVANCED_FEATURES.md
│   └── PHASE_4_DEPLOYMENT_TESTING.md
│
├── .github/
│   └── workflows/
│       ├── backend-tests.yml
│       ├── frontend-tests.yml
│       └── lint.yml
│
├── .gitignore
├── .pre-commit-config.yaml
└── README.md (root)
```

---

## **1.5 Development Workflow**

### Local Setup (Day 1)
1. Clone repository
2. Run `docker-compose up` to start all services
3. Backend API available at `http://localhost:8000`
4. Frontend available at `http://localhost:3000`
5. PostgreSQL at `localhost:5432`
6. Redis at `localhost:6379`

### Testing Locally
- Backend: `docker-compose exec backend pytest`
- Frontend: `docker-compose exec frontend npm test`
- Linting: `docker-compose exec backend black . && flake8` + `docker-compose exec frontend npm run lint`

### Git Workflow
- Main branch: stable, all tests passing
- Feature branches: `feature/DESCRIPTION`
- Pre-commit hooks: enforce linting before commits
- GitHub Actions: run tests and linting on PR

---

## **1.6 Coding Standards**

### Python (Backend)
- PEP 8 compliance (enforced by `black` and `flake8`)
- Type hints required for all functions
- Docstrings for all modules, classes, functions
- Line length: 88 characters (black default)
- Use `poetry` or `pip` for dependency management

### JavaScript (Frontend)
- ESLint configuration (airbnb or standard)
- Prettier for code formatting
- JSDoc comments for complex functions
- Component-based architecture
- Use `const` and `let`, avoid `var`
- Async/await over `.then()` chains

### Git Commit Messages
```
[PHASE-1] feat: Add FastAPI health endpoint
[PHASE-1] fix: Correct import path in routes
[PHASE-1] docs: Add coding standards guide
[PHASE-1] chore: Configure pre-commit hooks
```

Format: `[PHASE-X] <type>: <description>`

Types: `feat`, `fix`, `docs`, `chore`, `refactor`, `test`, `perf`

---

## **1.7 Success Criteria**

- [ ] FastAPI app runs without errors: `GET /health` returns `{"status": "ok"}`
- [ ] React app runs without errors and displays home page
- [ ] `docker-compose up` brings up all services successfully
- [ ] Pre-commit hooks installed and working
- [ ] GitHub Actions workflows run on PR and pass
- [ ] All documentation is complete and accurate
- [ ] Project README provides clear setup instructions
- [ ] No linting errors or warnings
- [ ] Test coverage at least 80% for health checks
- [ ] All team members can clone and run locally in <15 minutes

---

## **1.8 Timeline (2–3 weeks)**

| Milestone | Duration | Owner |
|-----------|----------|-------|
| Backend skeleton + FastAPI app | 2–3 days | Backend Lead |
| Frontend skeleton + React Router | 2–3 days | Frontend Lead |
| Docker Compose + local environment | 2 days | DevOps Lead |
| Pre-commit hooks + CI/CD workflows | 2 days | DevOps Lead |
| Documentation complete | 3–4 days | Tech Lead |
| Integration testing + refinement | 2–3 days | QA Lead |
| **Phase 1 Complete** | **2–3 weeks** | Team |

---

## **1.9 Dependencies & Blockers**
- None — Phase 1 is self-contained and requires no external dependencies
- No databases or external services needed yet

---

## **1.10 Known Risks & Mitigations**

| Risk | Probability | Impact | Mitigation |
|------|-------------|--------|------------|
| Python/Node version conflicts | Medium | High | Lock versions in .nvmrc and Dockerfile |
| Docker build failures | Medium | High | Test builds locally before committing |
| Pre-commit hook overhead | Low | Medium | Document bypass process for emergencies |
| Missing documentation | Low | High | Assign one owner to docs, weekly reviews |

---

**END OF PHASE 1 PLANNING**

Next: [PHASE 2 DEVELOPMENT](./PHASE_2_DEVELOPMENT.md)
