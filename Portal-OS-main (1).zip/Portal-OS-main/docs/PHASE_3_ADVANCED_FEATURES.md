# **PHASE 3 — ADVANCED FEATURES (4–6 weeks)**
**Outcome:** Portal‑OS becomes *company‑grade* — monitoring, analytics, notifications, RBAC.

---

## **3.1 Overview**
Phase 3 transforms Portal‑OS into an enterprise-ready platform with:
- Real-time monitoring and live dashboards (WebSockets)
- Advanced search with filtering, pagination, sorting
- File management (upload, download, attachments)
- Multi-channel notifications (email, in-app, webhooks)
- Reporting and analytics capabilities
- Role-Based Access Control (RBAC)
- Performance optimization (Redis caching, query tuning)
- Security hardening (OWASP, rate limiting, input validation)

---

## **3.2 Deliverables**

### Real-Time Monitoring
- [ ] WebSocket server setup (FastAPI with Starlette WebSockets)
- [ ] WebSocket connection management (connect, disconnect, broadcast)
- [ ] System status updates via WebSocket
- [ ] Live dashboard component (React)
- [ ] Real-time metrics streaming (CPU, memory, uptime)
- [ ] Connection lifecycle management (reconnect on failure)
- [ ] Load testing for concurrent WebSocket connections (100+)

### Advanced Search & Filtering
- [ ] Query builder for complex filters
- [ ] Filter operators: `eq`, `gt`, `lt`, `contains`, `in`, `between`
- [ ] Pagination (offset/limit + cursor-based)
- [ ] Multi-column sorting (asc/desc)
- [ ] Full-text search on user/system names
- [ ] Search result highlighting
- [ ] Frontend search UI with real-time results

### File Management
- [ ] File upload endpoint (`POST /files`)
- [ ] File download endpoint (`GET /files/{id}/download`)
- [ ] File deletion endpoint (`DELETE /files/{id}`)
- [ ] File storage (local disk or S3)
- [ ] File metadata DB table (name, size, type, uploader, timestamp)
- [ ] Virus scanning integration (ClamAV or similar)
- [ ] File attachment linking to systems/users
- [ ] Frontend file upload component (drag-and-drop)
- [ ] File list view with preview capability

### Notification System
- [ ] Email notification service (SMTP integration)
- [ ] In-app notification store (DB table)
- [ ] Webhook notification system (HTTP POST to external URLs)
- [ ] Notification preferences per user
- [ ] Email templates (welcome, password reset, system alerts)
- [ ] Notification queue (async processing with Celery or RQ)
- [ ] Retry logic for failed notifications
- [ ] In-app notification bell icon with count badge
- [ ] Notification history page

### Reporting & Analytics
- [ ] System usage metrics endpoint (`GET /metrics/systems`)
- [ ] User activity metrics endpoint (`GET /metrics/users`)
- [ ] Custom report builder
- [ ] Data export to CSV/PDF
- [ ] Time-series data aggregation (hourly, daily, weekly)
- [ ] Analytics dashboard with charts (Chart.js or Plotly.js)
- [ ] System uptime statistics
- [ ] User login/logout trends
- [ ] Performance benchmarks

### Role-Based Access Control (RBAC)
- [ ] Roles table (Admin, Manager, User, Viewer)
- [ ] Permissions table (create, read, update, delete per resource)
- [ ] Role-permission mapping table
- [ ] User-role assignment table
- [ ] `@require_permission('resource.action')` decorator
- [ ] Frontend route guards based on roles
- [ ] Role management UI (admin only)
- [ ] Permission inheritance model
- [ ] Dynamic permission checking

### Performance Optimization
- [ ] Redis caching layer for frequently accessed data
- [ ] Cache invalidation strategy
- [ ] Query optimization (indexes, eager loading)
- [ ] Database query profiling
- [ ] API response time monitoring
- [ ] Lazy loading on frontend
- [ ] Image optimization & CDN integration
- [ ] Gzip compression for responses
- [ ] Database connection pooling tuning

### Security Hardening
- [ ] OWASP Top 10 vulnerability audit
- [ ] Rate limiting (prevent brute force, DDoS)
- [ ] Input validation & sanitization
- [ ] SQL injection prevention (SQLAlchemy parameterized queries)
- [ ] XSS prevention (Content Security Policy headers)
- [ ] CSRF protection (CSRF tokens)
- [ ] Secure cookie settings (httpOnly, Secure, SameSite)
- [ ] HTTPS enforcement
- [ ] Dependency vulnerability scanning (Snyk, Dependabot)
- [ ] API key rotation mechanism

---

## **3.3 Database Schema Additions**

### Files Table
```sql
CREATE TABLE files (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  filename VARCHAR(255) NOT NULL,
  file_size BIGINT,
  mime_type VARCHAR(100),
  file_path VARCHAR(512) NOT NULL,
  uploader_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  system_id UUID REFERENCES systems(id) ON DELETE CASCADE,
  scan_status VARCHAR(50) DEFAULT 'pending', -- pending, clean, infected
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  deleted_at TIMESTAMP
);
```

### Notifications Table
```sql
CREATE TABLE notifications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  type VARCHAR(50) NOT NULL, -- email, in_app, webhook
  subject VARCHAR(255),
  message TEXT,
  recipient_email VARCHAR(255),
  webhook_url VARCHAR(512),
  status VARCHAR(50) DEFAULT 'pending', -- pending, sent, failed
  sent_at TIMESTAMP,
  retry_count INT DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE notification_preferences (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
  email_enabled BOOLEAN DEFAULT TRUE,
  in_app_enabled BOOLEAN DEFAULT TRUE,
  webhook_enabled BOOLEAN DEFAULT FALSE,
  webhook_url VARCHAR(512),
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### Roles & Permissions Tables
```sql
CREATE TABLE roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name VARCHAR(100) UNIQUE NOT NULL,
  description TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE permissions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  resource VARCHAR(100) NOT NULL,
  action VARCHAR(100) NOT NULL,
  description TEXT,
  UNIQUE(resource, action)
);

CREATE TABLE role_permissions (
  role_id UUID NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
  permission_id UUID NOT NULL REFERENCES permissions(id) ON DELETE CASCADE,
  PRIMARY KEY(role_id, permission_id)
);

CREATE TABLE user_roles (
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  role_id UUID NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
  assigned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY(user_id, role_id)
);
```

### Metrics Tables
```sql
CREATE TABLE system_metrics (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  system_id UUID NOT NULL REFERENCES systems(id) ON DELETE CASCADE,
  cpu_usage FLOAT,
  memory_usage FLOAT,
  disk_usage FLOAT,
  uptime_seconds BIGINT,
  request_count INT,
  error_count INT,
  response_time_ms FLOAT,
  recorded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

---

## **3.4 API Endpoints Reference**

### File Management
| Method | Endpoint | Description | Auth |
|--------|----------|-------------|------|
| POST | `/files` | Upload file | Yes |
| GET | `/files` | List files | Yes |
| GET | `/files/{id}` | Get file metadata | Yes |
| GET | `/files/{id}/download` | Download file | Yes |
| DELETE | `/files/{id}` | Delete file | Yes |

### Notifications
| Method | Endpoint | Description | Auth |
|--------|----------|-------------|------|
| GET | `/notifications` | List user notifications | Yes |
| GET | `/notifications/{id}` | Get notification | Yes |
| PUT | `/notifications/{id}/read` | Mark as read | Yes |
| DELETE | `/notifications/{id}` | Delete notification | Yes |
| PUT | `/notification-preferences` | Update preferences | Yes |

### Analytics & Metrics
| Method | Endpoint | Description | Auth |
|--------|----------|-------------|------|
| GET | `/metrics/systems` | System usage metrics | Yes |
| GET | `/metrics/users` | User activity metrics | Yes |
| GET | `/metrics/systems/{id}/history` | Historical metrics | Yes |
| POST | `/reports/generate` | Generate custom report | Yes |
| GET | `/reports/{id}/download` | Download report | Yes |

### Search & Advanced Filtering
| Method | Endpoint | Description | Auth |
|--------|----------|-------------|------|
| POST | `/search` | Advanced search | Yes |
| GET | `/systems?filter=...&sort=...&page=...` | Filtered systems list | Yes |

### RBAC Management
| Method | Endpoint | Description | Auth |
|--------|----------|-------------|------|
| GET | `/roles` | List roles | Yes (Admin) |
| POST | `/roles` | Create role | Yes (Admin) |
| GET | `/roles/{id}/permissions` | Get role permissions | Yes (Admin) |
| POST | `/roles/{id}/permissions` | Assign permission | Yes (Admin) |
| PUT | `/users/{id}/roles` | Update user roles | Yes (Admin) |

### WebSocket
| Event | Endpoint | Description |
|-------|----------|-------------|
| connect | `/ws/metrics` | Open WebSocket for real-time metrics |
| subscribe | Message | Subscribe to system updates |
| unsubscribe | Message | Unsubscribe from system updates |
| disconnect | Connection close | WebSocket disconnect |

---

## **3.5 WebSocket Implementation Example**

### Backend (FastAPI)
```python
# core-engine/app/api/websockets.py
from fastapi import WebSocket, WebSocketDisconnect

@app.websocket("/ws/metrics")
async def websocket_metrics(websocket: WebSocket):
    await websocket.accept()
    try:
        while True:
            # Receive subscription request
            data = await websocket.receive_json()
            system_id = data.get("system_id")
            
            # Send real-time metrics every 5 seconds
            while True:
                metrics = await get_system_metrics(system_id)
                await websocket.send_json({
                    "type": "metrics",
                    "system_id": system_id,
                    "data": metrics
                })
                await asyncio.sleep(5)
    except WebSocketDisconnect:
        # Clean up
        pass
```

### Frontend (React)
```javascript
// viewport/src/hooks/useWebSocket.js
import { useEffect, useState } from 'react';

export const useWebSocket = (url, systemId) => {
  const [metrics, setMetrics] = useState(null);
  
  useEffect(() => {
    const ws = new WebSocket(`ws://localhost:8000${url}`);
    
    ws.onopen = () => {
      ws.send(JSON.stringify({ system_id: systemId }));
    };
    
    ws.onmessage = (event) => {
      const data = JSON.parse(event.data);
      setMetrics(data.data);
    };
    
    return () => ws.close();
  }, [url, systemId]);
  
  return metrics;
};
```

---

## **3.6 RBAC Implementation Example**

### Backend Decorator
```python
# core-engine/app/middleware/rbac.py
from functools import wraps

def require_permission(resource: str, action: str):
    def decorator(func):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            user = kwargs.get('current_user')
            if not user:
                raise HTTPException(status_code=401)
            
            # Check if user has permission
            has_perm = await check_user_permission(
                user.id, resource, action
            )
            if not has_perm:
                raise HTTPException(status_code=403, detail="Forbidden")
            
            return await func(*args, **kwargs)
        return wrapper
    return decorator

# Usage:
@app.post("/systems")
@require_permission("system", "create")
async def create_system(data: SystemCreate, current_user: User):
    # Create system logic
    pass
```

### Frontend Route Guard
```javascript
// viewport/src/components/ProtectedRoute.jsx
import { useAuthStore } from '../store/authStore';

export const ProtectedRoute = ({ children, requiredRole }) => {
  const { user } = useAuthStore();
  
  if (!user) return <Redirect to="/login" />;
  
  if (requiredRole && !user.roles.includes(requiredRole)) {
    return <div>Access Denied</div>;
  }
  
  return children;
};
```

---

## **3.7 Success Criteria**

- [ ] WebSocket connections stable for 100+ concurrent users
- [ ] Real-time metrics update every 5 seconds without lag
- [ ] Advanced search returns results in <200ms
- [ ] File upload/download working for files up to 100MB
- [ ] Email notifications delivered within 1 minute
- [ ] RBAC permissions correctly enforced
- [ ] All OWASP vulnerabilities addressed
- [ ] Rate limiting prevents brute force attacks
- [ ] Cache hit rate >80% for frequently accessed data
- [ ] Query response times improved by 50%+
- [ ] 0 known security vulnerabilities (Snyk scan)
- [ ] Test coverage >85%
- [ ] Performance under load: 1000+ requests/second
- [ ] Uptime tracking accurate (within 1%)
- [ ] All analytics queries complete in <1 second

---

## **3.8 Timeline (4–6 weeks)**

| Milestone | Duration | Owner |
|-----------|----------|-------|
| WebSocket setup + metrics streaming | 5–6 days | Backend Lead |
| Advanced search & filtering | 4–5 days | Backend Lead |
| File management system | 4–5 days | Backend Lead |
| Notification system | 5–6 days | Backend Lead |
| RBAC implementation | 4–5 days | Backend Lead |
| Performance optimization | 4–5 days | Backend Lead |
| Security hardening | 4–5 days | Security Lead |
| Frontend dashboard (real-time metrics) | 5–6 days | Frontend Lead |
| Frontend file upload/download | 3–4 days | Frontend Lead |
| Frontend notifications UI | 3–4 days | Frontend Lead |
| Analytics/reporting UI | 4–5 days | Frontend Lead |
| Integration testing | 5–6 days | QA Lead |
| Documentation & refinement | 3–4 days | Tech Lead |
| **Phase 3 Complete** | **4–6 weeks** | Team |

---

## **3.9 Performance Targets**

| Metric | Target | Current |
|--------|--------|---------|
| API response time (p95) | <200ms | TBD |
| WebSocket latency | <100ms | TBD |
| Search query time | <200ms | TBD |
| File upload speed | 10MB/s | TBD |
| Cache hit rate | 80% | TBD |
| Page load time | <2s | TBD |

---

## **3.10 Known Risks & Mitigations**

| Risk | Probability | Impact | Mitigation |
|------|-------------|--------|------------|
| WebSocket connection drops | Medium | High | Implement auto-reconnect with exponential backoff |
| Email spam filter blocks notifications | Medium | Medium | Use transactional email service (SendGrid, AWS SES) |
| File upload causes disk space issues | Low | High | Implement quota per user, cleanup old files |
| Complex queries slow down search | Medium | High | Add database indexes, implement caching |
| RBAC permission check overhead | Low | Medium | Cache permissions in memory, invalidate on change |
| Rate limiting blocks legitimate users | Low | Medium | Use adaptive rate limiting, whitelist trusted IPs |

---

**END OF PHASE 3 PLANNING**

Next: [PHASE 4 DEPLOYMENT & OPERATIONS](./PHASE_4_DEPLOYMENT_TESTING.md)
